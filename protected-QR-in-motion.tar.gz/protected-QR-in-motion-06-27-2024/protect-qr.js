// Script.js 
// create a new QRCode instance 
let qrcode = new QRCode( 
    document.querySelector(".qrcode") 
); 
  
// Initial QR code generation 
// with a default message 
qrcode.makeCode("Why did you scan me?"); 
  
// Function to generate QR 
// code based on user input 
    //your code

function generateQr() { 
//show random generated QR code every 1/3 of a second to fool the eyeball to thinking the REAL QR code string is in motion
	var num = Math.floor(Math.random() * 90) + 100;
        qrcode.makeCode(document.querySelector("textarea").value+num); 
    setTimeout(generateQr, 300);
}


generateQr();

function generateQr2() { 
//show real actual qr code every 1/5 of a second
        qrcode.makeCode(document.querySelector("textarea").value); 
    setTimeout(generateQr2, 200);
}


generateQr2();
